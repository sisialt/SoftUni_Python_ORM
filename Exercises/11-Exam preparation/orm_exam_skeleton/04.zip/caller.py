import os
import django
from django.db.models import Q, Count

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Profile, Product, Order


def get_profiles(search_string=None):
    if search_string is None:
        return ""

    query_full_name = Q(full_name__icontains=search_string)
    query_email = Q(email__icontains=search_string)
    query_phone_number = Q(phone_number__icontains=search_string)

    profiles = Profile.objects.annotate(
        num_orders=Count('orders')
    ).filter(
        query_full_name | query_email | query_phone_number
    ).order_by('full_name')

    if not profiles:
        return ""

    result = []

    for p in profiles:
        result.append(f"Profile: {p.full_name}, "
                      f"email: {p.email}, "
                      f"phone number: {p.phone_number}, "
                      f"orders: {p.num_orders}")

    return '\n'.join(result)


def get_loyal_profiles():
    profiles = Profile.objects.get_regular_customers()

    if not profiles:
        return ""

    result = []

    for p in profiles:
        result.append(f"Profile: {p.full_name}, orders: {p.num_orders}")

    return '\n'.join(result)


def get_last_sold_products():
    last_order = Order.objects.order_by('-creation_date').first()

    if not last_order or not last_order.products.all():
        return ""

    products = last_order.products.order_by('name')

    return f"Last sold products: {', '.join([p.name for p in products])}"



# print(get_last_sold_products())