import os
import django


# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here

from django.db.models import Q, Count
from main_app.models import Author


def get_authors(search_name=None, search_email=None):
    if search_name is None and search_email is None:
        return ""

    query_name = Q(full_name__icontains=search_name)
    query_email = Q(email__icontains=search_email)

    if search_name and search_email:
        query = query_name & query_email
    elif search_name:
        query = query_name
    else:
        query = query_email

    authors = Author.objects.filter(query).order_by('-full_name')

    if not authors:
        return ""

    result = []

    for a in authors:
        result.append(f"Author: {a.full_name}, "
                      f"email: {a.email}, "
                      f"status: {'Banned' if a.is_banned else 'Not Banned'}")

    return '\n'.join(result)


def get_top_publisher():
    top_author = Author.objects.get_authors_by_article_count().first()

    if not top_author or not top_author.num_articles:
        return ""

    return f"Top Author: {top_author.full_name} with {top_author.num_articles} published articles."


def get_top_reviewer():
    author = Author.objects.annotate(
        num_reviews=Count('reviews')
    ).order_by(
        '-num_reviews',
        'email'
    ).first()

    if not author or not author.num_reviews:
        return ""

    return f"Top Reviewer: {author.full_name} with {author.num_reviews} published reviews."


