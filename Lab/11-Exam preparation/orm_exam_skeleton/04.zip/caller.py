import os
import django
from django.db.models import Count, Avg

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Director, Movie, Actor


def get_directors(search_name=None, search_nationality=None):
    result = []
    if search_name is None and search_nationality is None:
        return ""

    if search_name is None:
        directors = Director.objects.filter(nationality__icontains=search_nationality).order_by('full_name')
        if not directors:
            return ""
        for director in directors:
            result.append(f"Director: {director.full_name}, "
                          f"nationality: {director.nationality}, "
                          f"experience: {director.years_of_experience}")
        return '\n'.join(result)

    if search_nationality is None:
        directors = Director.objects.filter(full_name__icontains=search_name).order_by('full_name')
        if not directors:
            return ""
        for director in directors:
            result.append(f"Director: {director.full_name}, "
                          f"nationality: {director.nationality}, "
                          f"experience: {director.years_of_experience}")
        return '\n'.join(result)

    directors = (Director.objects.filter(full_name__icontains=search_name, nationality__icontains=search_nationality)
                 .order_by('full_name'))
    if not directors:
        return ""
    for director in directors:
        result.append(f"Director: {director.full_name}, "
                      f"nationality: {director.nationality}, "
                      f"experience: {director.years_of_experience}")
    return '\n'.join(result)


def get_top_director():
    top_director = Director.objects.get_directors_by_movies_count().first()
    if not top_director:
        return ""

    return f"Top Director: {top_director.full_name}, movies: {top_director.num_movies}."


def get_top_actor():
    if not Movie.objects.all() or not Movie.objects.exclude(starring_actor__isnull=True):
        return ""

    top_actor = Actor.objects.annotate(num_movies=Count('movie')).order_by('-num_movies', 'full_name').first()
    movies = top_actor.movie_set.all()
    avg_rating = movies.aggregate(av_rat=Avg('rating'))['av_rat']

    return (f"Top Actor: {top_actor.full_name}, "
            f"starring in movies: {', '.join([m.title for m in movies])}, "
            f"movies average rating: {avg_rating:.1f}")


# director = Director.objects.get(pk=4)
# movie = Movie.objects.first()
# print(movie.director)
# print(director.movie_set.all())
# actor = Actor.objects.create(
#     full_name='Sis Yo',
#
# )
# movie = Movie.objects.create(
#     title='movie',
#     release_date='2023-08-01',
#     director=Director.objects.all().first(),
#     starring_actor=Actor.objects.all().first(),
#
# )
# print(get_top_actor())